export enum OrderStatusEnum {
    NEW = "NEW",
    PAYED = "PAYED",
    SHIPPED = "SHIPPED",
    CANCELED = "CANCELED"
} 