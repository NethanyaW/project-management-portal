export const sample_users: any[] = [
    {
      name: "Ishan Gayantha",
      email: "hackishmax@gmail.com",
      password: "12345",
      address: "No.23",
      isAdmin: true,
    },
    {
      name: "Jane Doe",
      email: "Jane@gmail.com",
      password: "12345",
      address: "Shanghai",
      isAdmin: false,
    },
  ];