import {FoodModel} from "../models/Food.model";
import { sample_foods } from "../samples/data";

class FoodService {
    constructor() {}

    async getAllFoods() {
        const foods= await FoodModel.find();
        return foods;
    }

    async getAllFoodsBySearchTerm(term:RegExp):Promise<any[]>{
        return await FoodModel.find({name: {$regex:term}});
    }

    async getAllFoodsByTags(tag:string):Promise<any[]>{
        // if(tag.toLowerCase()==="all"){return sample_foods;} else {return sample_foods.filter(item => item.tags?.includes(tag));}
        const foods = await FoodModel.find({tags: tag})
        return foods;
    }

    async createFood(iob: any) {
        // const newFood = new Food(iob);
        // const createdFood = await newFood.save();
        // return createdFood;
    }

    async getFood(id: any) {
        const food = await FoodModel.findById(id);
        return food;
        // return sample_foods.find(items=>items.id==id);
    }

    async putFood(id: any, obj: any) {
        const food = await FoodModel.findByIdAndUpdate(id, obj);
        return food;
    }

    async deleteFood(id: any) {
        // const delFood = await Food.findByIdAndDelete(id);
        // return delFood;
    }

}

export default new FoodService;