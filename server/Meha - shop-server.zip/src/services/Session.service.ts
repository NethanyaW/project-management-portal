import {Session} from 'express-session';

class SessionService {
    constructor() {}

    createSession(user) {
        return user;
    }
}