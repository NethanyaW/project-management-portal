import mongoose from 'mongoose';

const Schema = mongoose.Schema;
const objectID = mongoose.Types.ObjectId;

export interface Food{
    id:string;
    name:string;
    price:number;
    tags: string[];
    favorite:boolean;
    stars: number;
    imageUrl: string;
    origins: string[];
    cookTime:string;
    qty:number;
}

const Food = new Schema({
    name: String,
    price: Number,
    tags: [String],
    favorite: Boolean,
    stars: Number,
    image: String,
    origins: [String],
    cookTime: String,
    qty: Number
},{
    toJSON:{
        virtuals: true
    },
    toObject:{
        virtuals: true
    },
    timestamps:true
});

export const FoodModel = mongoose.model("Food", Food);

