import FoodsService from "../services/Foods.service";

class FoodController {
    constructor() {}

    async getFoods (req:any, res:any) {
        const staffs = await FoodsService.getAllFoods();
        res.json(staffs);
    }

    async getAllFoodsBySearchTerm (req:any, res: any){
        const term = new RegExp(req.params.searchTerm, 'i');
        const rows = await FoodsService.getAllFoodsBySearchTerm(term);
        res.json(rows);
    }

    async getAllFoodsByTags (req:any, res: any){
        const tag = req.params.tag;
        const rows = await FoodsService.getAllFoodsByTags(tag);
        res.json(rows);
    }

    async createFoods (req:any, res:any) {
        const newFood = await FoodsService.createFood(req.body);
        res.json(newFood);
    }

    async getFood (req:any, res:any) {
        const id = req.params.id;
        const row = await FoodsService.getFood(id);
        res.json(row);
    }

    async putFood(req:any, res:any) {
        const id = req.params.id;
        const obj = req.body;
        const staff = await FoodsService.putFood(id, obj);
        res.json(staff);
    }

    async deleteFood (req:any, res:any) {
        const id = req.params.id;
        const staff = await  FoodsService.deleteFood(id);
        res.json(staff);
    }
}

export default new FoodController;