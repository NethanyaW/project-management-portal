import { Router } from 'express';
import asyncHandler from 'express-async-handler'
import httpStatus from 'http-status';
import FoodsController from '../controller/Foods.controller';
import TagsController from '../controller/Tags.controller';
import {FoodModel} from '../models/Food.model';
import RateModel from '../models/rate.model';
import { sample_foods } from '../samples/data';

const app = Router();

app.get('/seed', asyncHandler(async (req, res) => {
    const foodCount = await FoodModel.countDocuments();
    if(foodCount>0) {
        res.send("Foods are Seeding...");
        return;
    }
    await FoodModel.create(sample_foods);
    res.send("Seeding is done");
}))

app.route('/')
    .get(FoodsController.getFoods)
    .post(FoodsController.createFoods);

app.route('/food/:id')
    .get(FoodsController.getFood).patch(FoodsController.putFood);

app.route('/search/:searchTerm')
    .get(FoodsController.getAllFoodsBySearchTerm);

app.route('/tag/:tag')
    .get(FoodsController.getAllFoodsByTags);

app.route('/tags')
    .get(TagsController.getTags);

app.route('/rate/:item').get(asyncHandler(async (req, res) => {
    const item = req.params.item;
    const rates:any[] = await RateModel.find({item});
    if(!rates) {
        res.status(httpStatus.NOT_FOUND).send("No Rratings available");
        return;
    }
    res.send({rates:rates[0].rates, raters:rates[0].rates.length, all:rates[0]});
}));
app.route('/rate/:item').patch(asyncHandler(async (req, res) => {
    
    const itemID = req.params.item;
    const rate = req.body;
    var rates = await RateModel.findOneAndUpdate({item: itemID}, rate);
    if(!rates) {
        rates = await RateModel.create(rate);
    }
    res.send(rates);
}));

export default app;